
.. Copyright BigchainDB GmbH and BigchainDB contributors
   SPDX-License-Identifier: (Apache-2.0 AND CC-BY-4.0)
   Code is Apache-2.0 and docs are CC-BY-4.0

Ways to Contribute
==================

.. toctree::
   :maxdepth: 1

   report-a-bug
   write-an-issue
   make-a-feature-request-or-proposal
   write-a-bep
   write-docs
   answer-questions
