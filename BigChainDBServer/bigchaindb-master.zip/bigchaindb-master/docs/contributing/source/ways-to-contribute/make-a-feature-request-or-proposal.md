<!---
Copyright BigchainDB GmbH and BigchainDB contributors
SPDX-License-Identifier: (Apache-2.0 AND CC-BY-4.0)
Code is Apache-2.0 and docs are CC-BY-4.0
--->

# Make a Feature Request or Proposal

To make a feature request or proposal, [write a BigchainDB Enhancement Proposal (BEP)](write-a-bep).
