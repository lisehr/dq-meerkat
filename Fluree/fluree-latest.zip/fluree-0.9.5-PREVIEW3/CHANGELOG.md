# Changelog

## 0.9.5-PREVIEW2

- Raft snapshots only happening at reboots, not purging
- Multi-cardinality recursion fix
- Multi-cardinality delete transaction fix

